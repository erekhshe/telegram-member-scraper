chrome.runtime.onMessage.addListener((data, sender, sendResponse) => {
	if (data.msg === 'do-scraping') {
		DoScrape()
	}
});

//https://stackoverflow.com/questions/5525071/how-to-wait-until-an-element-exists
//helper function --> wait for an element to load completely
function waitForElm(selector) {
    return new Promise(resolve => {
        if (document.querySelector(selector)) {
            return resolve(document.querySelector(selector));
        }
        const observer = new MutationObserver(mutations => {
            if (document.querySelector(selector)) {
                resolve(document.querySelector(selector));
                observer.disconnect();
            }
        });
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    });
}

async function DoScrape(){
	//create a notifer element
	let notifer_el = document.createElement("div");
	notifer_el = document.createElement("div");
	notifer_el.style.zIndex = 999;
	notifer_el.style.backgroundColor = "#0080ff";
	notifer_el.style.color = "#ffffff";
	notifer_el.style.position = "absolute";
	notifer_el.style.left = "12px";
	notifer_el.style.top = "12px";
	notifer_el.style.width = "300px";
	notifer_el.style.fontSize = "smaller";
	notifer_el.style.padding = "6px 10px 6px 8px";
	notifer_el.style.border = "3px solid #ffd000";
	notifer_el.style.borderRadius = "7px";
	notifer_el.innerHTML = "Telegram Member Scraper (by v-User) </ br> Scraping process started...";
	console.log("Scraping process started...");
	document.body.insertBefore(notifer_el, document.body.firstChild); 

	var all_members_info = "";

	const memberRows = document.querySelectorAll("div.members-list>div.chat-item-clickable");
	if (memberRows.length) {
	  const member_amount_info = `Found ${memberRows.length} members`;
	  notifer_el.innerHTML = "Telegram Member Scraper (by v-User) </ br> " + member_amount_info;
	  console.log(member_amount_info);
	  var index = 0;
	  while (index < memberRows.length)
	  {
		//group page (member-list)
		const elm = await waitForElm('div.members-list');
			const userLink = document.querySelectorAll("div.members-list>div.chat-item-clickable")[index].firstChild;
			if (userLink) {
			  const member_number_info = `Member ${index + 1}`;
			  notifer_el.innerHTML = "Telegram Member Scraper (by v-User) </ br> " + member_number_info;
			  console.log(member_number_info);
			  userLink.dispatchEvent(new MouseEvent("mousedown", {view: window, bubbles: true, cancelable: true, buttons: 1}));

			  //profile page (member)
				const elm = await waitForElm('i.icon-phone, div.ChatInfo>div.Avatar.size-medium.saved-messages');
					const name = document.querySelector("div.ProfileInfo h3.fullName");
					const nameText = name ? name.textContent : '';
					const username = document.querySelector("div.ChatExtra span.title");
					const usernameText = username ? username.textContent : '';
					const bio = document.querySelector("div.ChatExtra span.title.word-break");
					const bioText = bio ? bio.textContent : '';
					const current_member_info = `Name: ${nameText}, Username: ${usernameText}, Bio: ${bioText}`;
					all_members_info += current_member_info + " \n"; 
					notifer_el.innerHTML = "Telegram Member Scraper (by v-User) <br> " + current_member_info;
					console.log(current_member_info);
					const backButton = document.querySelector("div.messages-layout button[title=Back]");
					if (backButton) {
					  backButton.click(); //back to member-list
					}
			}
		index++;
	  }
	  notifer_el.innerHTML = "Telegram Member Scraper (by v-User) </ br> Scraping process finished.";
	  console.log("Scraping process finished.");
	  
	  //get group name as export file name
	  fnE = document.querySelector("div.MiddleHeader h3");
	  let fn = fnE ? fnE.textContent : "v-user-export-data.txt";
	  fn = fn.replace(/[/\\?%*:|"<>]/g, '-'); //remove illegal chars from the file name
	  
	  //save as a text file
	  const uri = "data:text/plain;charset=utf-8," + all_members_info;  
	  let ea = document.createElement("a");
		ea.href = uri;
		ea.download = fn; //group name
		document.body.appendChild(ea);
		ea.click();
		document.body.removeChild(ea);
		
	} else {
	  notifer_el.style.backgroundColor = "#ad0000";
	  notifer_el.innerHTML = "Telegram Member Scraper (by v-User) </ br> Error: Members list is not visible!";
	  console.log("Error: Members list is not visible!");
	}
	document.body.removeChild(notifer_el);
}